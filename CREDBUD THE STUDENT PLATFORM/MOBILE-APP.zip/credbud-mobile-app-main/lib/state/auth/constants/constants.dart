import 'package:flutter/foundation.dart';

@immutable
class Constants {
  // ToDo: Change to actual domain while deploying i.e sinhgad.edu
  static const sinhgadDomain = 'gmail.com';
  const Constants._();
}
